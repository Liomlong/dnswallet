declare module 'tonweb' {
  // 这里可以添加任何需要的类型声明
  // 如果 TypeScript 仍然报错，可以根据错误信息添加更多的类型声明
}