declare interface Window {
  Telegram: {
    WebApp: {
      initDataUnsafe: {
        user?: {
          username?: string;
        };
      };
    };
  };
}
